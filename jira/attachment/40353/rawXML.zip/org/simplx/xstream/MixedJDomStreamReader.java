package org.simplx.xstream;

import com.thoughtworks.xstream.io.xml.JDomReader;
import org.jdom.Content;
import org.jdom.Element;
import org.jdom.Parent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * A reader that manages mixed text and nodes in an XML stream.
 *
 * @author Ken Arnold
 */
@SuppressWarnings({"unchecked"})
public class MixedJDomStreamReader extends JDomReader
        implements MixedStreamReader {

    /**
     * Creates a new {@link MixedJDomStreamReader}.
     *
     * @param elem The element at the top of the subtree of XML that is managed
     *             by this reader.
     */
    public MixedJDomStreamReader(Element elem) {
        super(elem);
    }

    public Iterator partIterator() {
        Parent elem = (Parent) getCurrent();
        List kids = elem.getContent();
        List parts = new ArrayList<Object>();
        for (final Object child : kids) {
            if (child instanceof Element) {
                parts.add(new NodePart() {
                    public String nodeName() {
                        return ((Element) child).getName();
                    }
                });
            } else {
                parts.add(new TextPart() {
                    public String contents() {
                        return ((Content) child).getValue();
                    }
                });
            }
        }
        return Collections.unmodifiableList(parts).iterator();
    }
}