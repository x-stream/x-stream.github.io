package org.simplx.xstream;

import com.thoughtworks.xstream.io.xml.JDomDriver;
import org.jdom.Element;

/**
 * Converts XML to a JDom element and vice versa. This converter allows you to
 * embed an arbitrary JDom-based XML tree, unparsed by XStream, into an object.
 * For example:
 * <pre>
 *  &#064;XStreamAlias("rawHolder")
 *  public static class RawHolder {
 *      public String name;
 *      public org.jdom.Element doc;
 *      public long value;
 *  }
 * &nbsp;
 *     ...
 *     XStream xstream = new XStream(new JDomDriver());
 *     xstream.registerConverter(new AsJDomConverter());
 *     RawHolder rh = new RawHolder();
 *     xstream.fromXML(in, rh);
 *     ...
 * </pre>
 * In this case, the XML would look something like this:
 * <pre>
 *  &lt;rawHolder&gt;
 *    &lt;name&gt;rawName&lt;/name&gt;
 *    &lt;doc&gt;
 *      &lt;whatever&gt;inside&lt;/whatever&gt;
 *    &lt;/doc&gt;
 *    &lt;value&gt;13&lt;/value&gt;
 *  &lt;/rawHolder&gt;
 * </pre>
 * Everything inside the {@code <doc>} tag will be read into the {@code
 * RawHolder} object's {@code doc} field as an XML element.  The driver must be
 * {@link JDomDriver} (or any other driver that produces {@link
 * org.jdom.Element} objects) to be compatible with the field type. The {@link
 * JDomDriver} will create the XML objects, and the object in {@code doc} will
 * be an {@link org.jdom.Element Element} for the {@code <whatever>} tag and its
 * contents.
 *
 * @author Ken Arnold
 */
@SuppressWarnings({"UnnecessaryFullyQualifiedName"})
public class JDomConverter extends XmlDocConverter {
    /**
     * Returns {@code true} if the type is named {@code "org.jdom.Element"}.
     *
     * @param type The type.
     *
     * @return {@code true} if the type is named {@code "org.jdom.Element"}.
     */
    public boolean canConvert(Class type) {
        try {
            Class elemClass = Class.forName("org.jdom.Element");
            return elemClass.isAssignableFrom(type);
        } catch (ClassNotFoundException ignored) {
            return false;
        }
    }

    @Override
    protected MixedStreamReader createReader(Object source) {
        return new MixedJDomStreamReader((Element) source);
    }
}