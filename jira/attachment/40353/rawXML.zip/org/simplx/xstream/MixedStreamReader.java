package org.simplx.xstream;

import com.thoughtworks.xstream.io.HierarchicalStreamReader;

import java.util.Iterator;

/**
 * A stream reader that handles mixed text and XML content.
 *
 * @author Ken Arnold
 */
public interface MixedStreamReader extends HierarchicalStreamReader {
    /** An XML node part of the mixed stream. */
    interface NodePart {
        /**
         * Returns the name of the node.
         *
         * @return The name of the node.
         */
        String nodeName();
    }

    /** A text part of the mixed stream. */
    interface TextPart {
        /**
         * Returns the text of this part of the stream.
         *
         * @return The text of this part of the stream.
         */
        String contents();
    }

    /**
     * Returns an iterator that goes through the parts of mixed content.
     *
     * @return An iterator that walks through a sequence of {@link NodePart} and
     *         {@link TextPart} nodes.
     */
    Iterator partIterator();
}