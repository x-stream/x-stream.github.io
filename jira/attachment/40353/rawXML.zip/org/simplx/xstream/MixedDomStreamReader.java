package org.simplx.xstream;

import com.thoughtworks.xstream.io.xml.DomReader;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.Arrays;
import java.util.Iterator;

/**
 * A reader that manages mixed text and nodes in an XML stream.
 *
 * @author Ken Arnold
 */
public class MixedDomStreamReader extends DomReader
        implements MixedStreamReader {

    /**
     * Creates a new {@link MixedDomStreamReader}.
     *
     * @param elem The element at the top of the subtree of XML that is managed
     *             by this reader.
     */
    public MixedDomStreamReader(Element elem) {
        super(elem);
    }

    public Iterator partIterator() {
        Node elem = (Node) getCurrent();
        NodeList kids = elem.getChildNodes();
        Object[] parts = new Object[kids.getLength()];
        for (int i = 0; i < kids.getLength(); i++) {
            final Node child = kids.item(i);
            if (child instanceof Element) {
                parts[i] = new NodePart() {
                    public String nodeName() {
                        return child.getNodeName();
                    }
                };
            } else {
                parts[i] = new TextPart() {
                    public String contents() {
                        return child.getTextContent();
                    }
                };
            }
        }
        return Arrays.asList(parts).iterator();
    }
}