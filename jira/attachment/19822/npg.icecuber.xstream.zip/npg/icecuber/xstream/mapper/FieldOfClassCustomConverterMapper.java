package npg.icecuber.xstream.mapper;

import java.util.HashMap;

import npg.icecuber.xstream.converters.extended.SingleValueConverterToConverterWrapper;

import org.apache.log4j.Logger;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.ConverterLookup;
import com.thoughtworks.xstream.converters.SingleValueConverter;
import com.thoughtworks.xstream.mapper.AttributeAliasingMapper;
import com.thoughtworks.xstream.mapper.Mapper;

public class FieldOfClassCustomConverterMapper extends AttributeAliasingMapper {
    /**
     * Logger for this class
     */
    private static final Logger logger = Logger
            .getLogger(FieldOfClassCustomConverterMapper.class);

    // mappa
    private HashMap fieldOfClassCustomConverterMap = new HashMap();

    // private HashMap fieldToOwnTagWithAttributeMap = new HashMap();

    public FieldOfClassCustomConverterMapper(Mapper wrapped) {
        super(wrapped);
        // TODO Auto-generated constructor stub
    }

    public FieldOfClassCustomConverterMapper(Mapper wrapped,
            ConverterLookup converterLookup) {
        super(wrapped, converterLookup);

    }

    public boolean hasFieldOfClassCustomConverter(String fieldName,
            Class definedInClass) {
        if (logger.isDebugEnabled()) {
            logger.debug("isFieldOfClassToAttribute(String, Class) - start");
        }

        // se non ho mappings per questa classe
        if (!fieldOfClassCustomConverterMap.containsKey(definedInClass
                .getName()))
            return false;

        HashMap classMap = (HashMap) fieldOfClassCustomConverterMap
                .get(definedInClass.getName());
        boolean returnboolean = classMap.containsKey(fieldName);
        if (logger.isDebugEnabled()) {
            logger.debug("isFieldOfClassToAttribute(String, Class) - end");
        }
        return returnboolean;
    }

    public void addCustomConverterForFieldOfClass(
            SingleValueConverter singleValueConverter, final String fieldName,
            final Class definedInClass) {
        this
                .addCustomConverterForFieldOfClass(
                        new SingleValueConverterToConverterWrapper(
                                singleValueConverter), fieldName,
                        definedInClass);

    }

    public void addCustomConverterForFieldOfClass(Converter converter,
            final String fieldName, final Class definedInClass) {
        HashMap classMap;
        // controllo se ho gi� mapping per questa classe
        if (fieldOfClassCustomConverterMap
                .containsKey(definedInClass.getName())) {
            // se ho gi� un mapping lo ricavo
            classMap = (HashMap) fieldOfClassCustomConverterMap
                    .get(definedInClass.getName());
        } else {
            // se non ne ho, creo un HashMap apposta
            classMap = new HashMap();
        }
        // aggiungo il mapping della classe
        classMap.put(fieldName, converter);
        // aggiungo il mapping della classe ai mapping
        fieldOfClassCustomConverterMap.put(definedInClass.getName(), classMap);
    }

    public Converter getCustomConverterForFieldOfClass(final String fieldName,
            final Class definedInClass) {
        HashMap classMap;
        // controllo se ho gi� mapping per questa classe
        if (fieldOfClassCustomConverterMap
                .containsKey(definedInClass.getName())) {
            // se ho gi� un mapping lo ricavo
            classMap = (HashMap) fieldOfClassCustomConverterMap
                    .get(definedInClass.getName());
            // e ritorno il corrispondente mapping
            return (Converter) classMap.get(fieldName);
        } else {
            // se non ne ho, ritorno null
            return null;
        }
    }
}
