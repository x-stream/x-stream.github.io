package npg.icecuber.xstream.mapper;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.thoughtworks.xstream.mapper.Mapper;
import com.thoughtworks.xstream.mapper.MapperWrapper;

public class AttributeClassAliasingMapper extends MapperWrapper {
    /**
     * Logger for this class
     */
    private static final Logger logger = Logger
            .getLogger(AttributeClassAliasingMapper.class);

    // mappa
    private HashMap fieldToParentTagAttributeMap = new HashMap();

    private HashMap fieldToOwnTagWithAttributeMap = new HashMap();

    public AttributeClassAliasingMapper(Mapper wrapped) {
        super(wrapped);
    }
//
//    public AttributeClassAliasingMapper(Mapper wrapped,
//            ConverterLookup converterLookup) {
//        super(wrapped, converterLookup);
//
//    }

    public boolean isFieldOfClassToParentTagAttribute(String fieldName,
            Class definedInClass) {
        if (logger.isDebugEnabled()) {
            logger.debug("isFieldOfClassToAttribute(String, Class) - start");
        }

        // se non ho mappings per questa classe
        if (!fieldToParentTagAttributeMap.containsKey(definedInClass.getName()))
            return false;

        HashMap classMap = (HashMap) fieldToParentTagAttributeMap
                .get(definedInClass.getName());
        boolean returnboolean = classMap.containsKey(fieldName);
        if (logger.isDebugEnabled()) {
            logger.debug("isFieldOfClassToAttribute(String, Class) - end");
        }
        return returnboolean;
    }

    public void addAliasForFieldOfClassToParentTagAttribute(
            final String fieldName, final String fieldNameAttributeAliasName,
            final Class definedInClass) {
        HashMap classMap;
        // controllo se ho gi� mapping per questa classe
        if (fieldToParentTagAttributeMap.containsKey(definedInClass.getName())) {
            // se ho gi� un mapping lo ricavo
            classMap = (HashMap) fieldToParentTagAttributeMap
                    .get(definedInClass.getName());
        } else {
            // se non ne ho, creo un HashMap apposta
            classMap = new HashMap();
        }
        // aggiungo il mapping della classe
        classMap.put(fieldName, fieldNameAttributeAliasName);
        // aggiungo il mapping della classe ai mapping
        fieldToParentTagAttributeMap.put(definedInClass.getName(), classMap);
    }

    public String getAliasForFieldOfClassToParentTagAttribute(
            final String fieldName, final Class definedInClass) {
        HashMap classMap;
        // controllo se ho gi� mapping per questa classe
        if (fieldToParentTagAttributeMap.containsKey(definedInClass
                .getName())) {
            // se ho gi� un mapping lo ricavo
            classMap = (HashMap) fieldToParentTagAttributeMap
                    .get(definedInClass.getName());
            // e ritorno il corrispondente mapping
            return "" + classMap.get(fieldName);
        } else {
            // se non ne ho, ritorno lo stesso fieldName
            return fieldName;
        }
    }

    public boolean isFieldOfClassToOwnTagAttribute(String fieldName,
            Class definedInClass) {
        if (logger.isDebugEnabled()) {
            logger.debug("isFieldOfClassToAttribute(String, Class) - start");
        }

        // se non ho mappings per questa classe
        if (!fieldToOwnTagWithAttributeMap
                .containsKey(definedInClass.getName()))
            return false;

        HashMap classMap = (HashMap) fieldToOwnTagWithAttributeMap
                .get(definedInClass.getName());
        boolean returnboolean = classMap.containsKey(fieldName);
        if (logger.isDebugEnabled()) {
            logger.debug("isFieldOfClassToAttribute(String, Class) - end");
        }
        return returnboolean;
    }

    public void addAliasForFieldOfClassToOwnTagAttribute(
            final String fieldName, final String fieldNameAttributeAliasName,
            final Class definedInClass) {
        HashMap classMap;
        // controllo se ho gi� mapping per questa classe
        if (fieldToOwnTagWithAttributeMap.containsKey(definedInClass.getName())) {
            // se ho gi� un mapping lo ricavo
            classMap = (HashMap) fieldToOwnTagWithAttributeMap
                    .get(definedInClass.getName());
        } else {
            // se non ne ho, creo un HashMap apposta
            classMap = new HashMap();
        }
        // aggiungo il mapping della classe
        classMap.put(fieldName, fieldNameAttributeAliasName);
        // aggiungo il mapping della classe ai mapping
        fieldToOwnTagWithAttributeMap.put(definedInClass.getName(), classMap);
    }

    public String getAliasForFieldOfClassToOwnTagAttribute(
            final String fieldName, final Class definedInClass) {
        HashMap classMap;
        // controllo se ho gi� mapping per questa classe
        if (fieldToOwnTagWithAttributeMap.containsKey(definedInClass
                .getName())) {
            // se ho gi� un mapping lo ricavo
            classMap = (HashMap) fieldToOwnTagWithAttributeMap
                    .get(definedInClass.getName());
            // e ritorno il corrispondente mapping
            return "" + classMap.get(fieldName);
        } else {
            // se non ne ho, ritorno lo stesso fieldName
            return fieldName;
        }
    }
}
