/**
 * 
 */
package npg.icecuber.xstream.mapper;

import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import com.thoughtworks.xstream.mapper.Mapper;
import com.thoughtworks.xstream.mapper.MapperWrapper;

/**
 * @author stefano.girotti
 * 
 */
public class FieldOrderMapper extends MapperWrapper {
    /**
     * Logger for this class
     */
    private static final Logger logger = Logger
            .getLogger(FieldOrderMapper.class);

    private HashMap classFieldOrderListMap = new HashMap();

    // private ArrayList fieldOrderList = new ArrayList();

    /**
     * @param wrapped
     */
    public FieldOrderMapper(Mapper wrapped) {
        super(wrapped);
        // TODO Auto-generated constructor stub
    }

    public List getFieldOrderList(Class type) {
        if (logger.isDebugEnabled()) {
            logger.debug("getFieldOrderList(Class) - start");
        }

        List returnList = (List) classFieldOrderListMap.get(type.getName());
        if (logger.isDebugEnabled()) {
            logger.debug("getFieldOrderList(Class) - end");
        }
        if (returnList != null) {
            return returnList;
        } else
            return new ArrayList();
    }

    public void setFieldOrderList(Class type, List fieldOrderList) {
        classFieldOrderListMap.put(type.getName(), fieldOrderList);
    }

    public void setFieldOrderList(Class type, String[] fieldOrderArray) {
        this.setFieldOrderList(type, Arrays.asList(fieldOrderArray));
    }

    public void setFieldOrderList(Class type,
            String fieldOrderListCommaSeparetedFiledName) {
        setFieldOrderList(type, fieldOrderListCommaSeparetedFiledName, ",");
    }

    public void setFieldOrderList(Class type,
            String fieldOrderListCustomSeparetedFiledName, String delim) {
        StringTokenizer stok = new StringTokenizer(
                fieldOrderListCustomSeparetedFiledName, delim, false);
        ArrayList fieldOrderList = new ArrayList();
        while (stok.hasMoreTokens()) {
            fieldOrderList.add(stok.nextToken());
        }
        this.setFieldOrderList(type, fieldOrderList);
    }

    public void appendFieldInOrderList(Class type, String fieldName) {
        ArrayList fieldOrderList;
        if (classFieldOrderListMap.containsKey(type.getName())) {
            // ho gi� una lista con questa clase
            fieldOrderList = (ArrayList) classFieldOrderListMap.get(type
                    .getName());

        } else {
            // devo creare una lista x questa classe
            fieldOrderList = new ArrayList();
            classFieldOrderListMap.put(type.getName(), fieldOrderList);
        }
        fieldOrderList.add(fieldName);
    }

}
