package npg.icecuber.xstream.mapper;

import java.util.HashMap;

import npg.icecuber.xstream.converters.extended.SingleValueConverterToConverterWrapper;

import org.apache.log4j.Logger;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.ConverterLookup;
import com.thoughtworks.xstream.converters.SingleValueConverter;
import com.thoughtworks.xstream.mapper.AttributeAliasingMapper;
import com.thoughtworks.xstream.mapper.Mapper;

public class FieldOfClassDefaultValueMapper extends AttributeAliasingMapper {
    /**
     * Logger for this class
     */
    private static final Logger logger = Logger
            .getLogger(FieldOfClassDefaultValueMapper.class);

    // mappa
    private HashMap fieldOfClassDefaultValueMap = new HashMap();

    // private HashMap fieldToOwnTagWithAttributeMap = new HashMap();

    public FieldOfClassDefaultValueMapper(Mapper wrapped) {
        super(wrapped);
        // TODO Auto-generated constructor stub
    }

    public FieldOfClassDefaultValueMapper(Mapper wrapped,
            ConverterLookup converterLookup) {
        super(wrapped, converterLookup);

    }

    public boolean hasFieldOfClassDefaultValue(String fieldName,
            Class definedInClass) {
        if (logger.isDebugEnabled()) {
            logger.debug("isFieldOfClassToAttribute(String, Class) - start");
        }

        // se non ho mappings per questa classe
        if (!fieldOfClassDefaultValueMap.containsKey(definedInClass.getName()))
            return false;

        HashMap classMap = (HashMap) fieldOfClassDefaultValueMap
                .get(definedInClass.getName());
        boolean returnboolean = classMap.containsKey(fieldName);
        if (logger.isDebugEnabled()) {
            logger.debug("isFieldOfClassToAttribute(String, Class) - end");
        }
        return returnboolean;
    }

    // public void addDefaultValueForFieldOfClass(
    // SingleValueConverter singleValueConverter, final String fieldName,
    // final Class definedInClass) {
    // this
    // .addCustomConverterForFieldOfClass(
    // new SingleValueConverterToConverterWrapper(
    // singleValueConverter), fieldName,
    // definedInClass);
    //
    // }

    public void addDefaultValueForFieldOfClass(Object defaultValue,
            final String fieldName, final Class definedInClass) {
        HashMap classMap;
        // controllo se ho gi� mapping per questa classe
        if (fieldOfClassDefaultValueMap.containsKey(definedInClass.getName())) {
            // se ho gi� un mapping lo ricavo
            classMap = (HashMap) fieldOfClassDefaultValueMap.get(definedInClass
                    .getName());
        } else {
            // se non ne ho, creo un HashMap apposta
            classMap = new HashMap();
        }
        // aggiungo il mapping della classe
        classMap.put(fieldName, defaultValue);
        // aggiungo il mapping della classe ai mapping
        fieldOfClassDefaultValueMap.put(definedInClass.getName(), classMap);
    }

    public Object getDefaultValueForFieldOfClass(final String fieldName,
            final Class definedInClass) {
        HashMap classMap;
        // controllo se ho gi� mapping per questa classe
        if (fieldOfClassDefaultValueMap.containsKey(definedInClass
                .getName())) {
            // se ho gi� un mapping lo ricavo
            classMap = (HashMap) fieldOfClassDefaultValueMap.get(definedInClass
                    .getName());
            // e ritorno il corrispondente mapping
            return classMap.get(fieldName);
        } else {
            // se non ne ho, ritorno null
            return null;
        }
    }
}
