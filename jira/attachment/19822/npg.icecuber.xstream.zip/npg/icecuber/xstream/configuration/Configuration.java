package npg.icecuber.xstream.configuration;

import java.io.Serializable;

public class Configuration implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private static String utilDateFormat = "";

    private static String sqlDateFormat = "";

    private static String sqlTimeFormat = "";

    private static String sqlTimeStampFormat = "";

    private static String[] acceptableDateTimeFormats = {
            "yyyy-MM-dd HH:mm:ss.S a", "yyyy-MM-dd HH:mm:ssz",
            "yyyy-MM-dd HH:mm:ss z", // JDK 1.3 needs both versions
            "yyyy-MM-dd HH:mm:ssa" };

    private static boolean alwaysImplicitCommetcion = true;

    private static boolean trimAlwaysNeeded = true;

    private static boolean filteringCGLibAlwaysNeeded = true;

    private static boolean CGLibResolvesToClassNeeded = false;

    public static boolean isFilteringCGLibAlwaysNeeded() {
        return filteringCGLibAlwaysNeeded;
    }

    public static void setFilteringCGLibAlwaysNeeded(boolean alwaysFilterCGLib) {
        Configuration.filteringCGLibAlwaysNeeded = alwaysFilterCGLib;
    }

    public static boolean isAlwaysImplicitCommetcion() {
        return alwaysImplicitCommetcion;
    }

    public static void setAlwaysImplicitCommetcion(
            boolean alwaysImplicitCommetcion) {
        Configuration.alwaysImplicitCommetcion = alwaysImplicitCommetcion;
    }

    public static String getSqlDateFormat() {
        return sqlDateFormat;
    }

    public static void setSqlDateFormat(String sqlDateFormat) {
        Configuration.sqlDateFormat = sqlDateFormat;
    }

    public static String getSqlTimeFormat() {
        return sqlTimeFormat;
    }

    public static void setSqlTimeFormat(String sqlTimeFormat) {
        Configuration.sqlTimeFormat = sqlTimeFormat;
    }

    public static String getUtilDateFormat() {
        return utilDateFormat;
    }

    public static void setUtilDateFormat(String utilDateFormat) {
        Configuration.utilDateFormat = utilDateFormat;
    }

    public static boolean isCGLibResolvesToClassNeeded() {
        return CGLibResolvesToClassNeeded;
    }

    public static void setCGLibResolvesToClassNeeded(
            boolean suppressCGLibResolvesTo) {
        Configuration.CGLibResolvesToClassNeeded = suppressCGLibResolvesTo;
    }

    public static boolean isTrimAlwaysNeeded() {
        return trimAlwaysNeeded;
    }

    public static void setTrimAlwaysNeeded(boolean alwaysTrim) {
        Configuration.trimAlwaysNeeded = alwaysTrim;
    }

    public static String getSqlTimeStampFormat() {
        return sqlTimeStampFormat;
    }

    public static void setSqlTimeStampFormat(String sqlTimeStampFormat) {
        Configuration.sqlTimeStampFormat = sqlTimeStampFormat;
    }

    public static String[] getAcceptableDateTimeFormats() {
        return acceptableDateTimeFormats;
    }

    public static void setAcceptableDateTimeFormats(
            String[] acceptableDateTimeFormats) {
        Configuration.acceptableDateTimeFormats = acceptableDateTimeFormats;
    }

}
