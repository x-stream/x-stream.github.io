/**
 * 
 */
package npg.icecuber.xstream.converters.reflection;

import npg.icecuber.xstream.mapper.MapperProvider;

import com.thoughtworks.xstream.converters.reflection.Sun14ReflectionProvider;

/**
 * @author stefano.girotti
 * 
 */
public class ConfigurableReflectionProvider extends Sun14ReflectionProvider {
    private OrderFieldDictionary orderFieldDictionary;

    private MapperProvider mapperProvider;

    // private FieldOrderMapper fieldOrderMapper;

    /**
     * @param mapperProvider
     */
    public ConfigurableReflectionProvider(MapperProvider mapperProvider) {
        super();
        this.mapperProvider = mapperProvider;
        super.fieldDictionary = new OrderFieldDictionary(mapperProvider
                .getFieldOrderMapper());
    }

    public OrderFieldDictionary getOrderFieldDictionary() {
        return orderFieldDictionary;
    }

    public void setOrderFieldDictionary(
            OrderFieldDictionary orderFieldDictionary) {
        this.orderFieldDictionary = orderFieldDictionary;
    }

    public MapperProvider getMapperProvider() {
        return mapperProvider;
    }

    public void setMapperProvider(MapperProvider mapperWrapperProvider) {
        this.mapperProvider = mapperWrapperProvider;
    }

}
