package npg.icecuber.xstream.converters.reflection;

import npg.icecuber.xstream.configuration.Configuration;
import npg.icecuber.xstream.mapper.AttributeClassAliasingMapper;
import npg.icecuber.xstream.mapper.MapperProvider;

import org.apache.log4j.Logger;

import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.reflection.ReflectionConverter;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

public class ConfigurableReflectionConverter extends ReflectionConverter {
    /**
     * Logger for this class
     */
    private static final Logger logger = Logger
            .getLogger(ConfigurableReflectionConverter.class);

    private AttributeClassAliasingMapper attributeClassAliasingMapper;

    private MapperProvider mapperWrapperProvider;

    // private ConfigurableReflectionConverter attributeClassAliasingMapper;
    private ReflectionVisitor reflectionVisitor;

    // protected FieldDictionary fieldDictionary = new FieldDictionary();

    public ConfigurableReflectionConverter(
            ConfigurableReflectionProvider configurablereflectionProvider) {
        super(configurablereflectionProvider.getMapperProvider().getMapper(),
                configurablereflectionProvider);
        reflectionVisitor = new ReflectionVisitor(
                configurablereflectionProvider);
        mapperWrapperProvider = configurablereflectionProvider
                .getMapperProvider();
        attributeClassAliasingMapper = mapperWrapperProvider
                .getAttributeClassAliasingMapper();
        logger.debug("attributeClassAliasingMapper vale: "
                + attributeClassAliasingMapper);
    }

    @Override
    public boolean canConvert(Class type) {
        return true;
    }

    @Override
    public void marshal(Object original, HierarchicalStreamWriter writer,
            MarshallingContext context) {
        if (logger.isDebugEnabled()) {
            logger
                    .debug("marshal(Object, HierarchicalStreamWriter, MarshallingContext) - start");
        }

        Object source = new Object();
        reflectionVisitor.setWriter(writer);
        reflectionVisitor.setContext(context);

        if (Configuration.isFilteringCGLibAlwaysNeeded()) {
            // per evitare casini con le cglib le riporto alla sua classe
            // originale
            source = serializationMethodInvoker.callWriteReplace(original);
        }
        logger.debug("original.getClass() vale: " + original.getClass()
                + " source � di tipo:  " + source.getClass());
        if (Configuration.isCGLibResolvesToClassNeeded())
            if (source.getClass() != original.getClass()) {
                writer.addAttribute(mapper.attributeForReadResolveField(),
                        mapper.serializedClass(source.getClass()));
            }
        logger
                .debug("chiamo visitSerializableFields con parametri: source vale: "
                        + source
                        + " source � di tipo:  "
                        + source.getClass()
                        + " reflectionVisitor vale: " + reflectionVisitor);
        reflectionProvider.visitSerializableFields(source, reflectionVisitor);
        if (logger.isDebugEnabled()) {
            logger
                    .debug("marshal(Object, HierarchicalStreamWriter, MarshallingContext) - end");
        }
    }

}