/**
 * 
 */
package npg.icecuber.xstream.converters.extended;

import java.sql.Date;

import com.thoughtworks.xstream.converters.basic.DateConverter;

/**
 * @author stefano.girotti
 * 
 */
public class SQLDateFormatConverter extends DateConverter {
    // SimpleDateFormat dateFormat;

    /**
     * @param pattern
     */
    public SQLDateFormatConverter(String defaultFormat,
            String[] acceptableFormats) {
        super(defaultFormat, acceptableFormats);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.thoughtworks.xstream.converters.Converter#canConvert(java.lang.Class)
     */
    public boolean canConvert(Class classeDaConvertire) {
        if (classeDaConvertire == null)
            return false;
        return classeDaConvertire.equals(Date.class);
    }
}
