package npg.icecuber.xstream.converters;

import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;

public interface MultiConverter {

    /**
     * Marshalls an Object into a value representation
     * 
     * @param obj
     *            the Object to be converted
     * @param writer
     * @param context
     *            A context that allows nested objects to be processed by
     *            XStream.
     * @return A String with the value of the Object
     */
    public String toString(String fieldName, Object obj, Class fieldType,
            Class definedInClass, MarshallingContext context);

    /**
     * Unmarshalls an Object from its single value representation
     * 
     * @param str
     *            the String with the single value of the Object
     * @return The Object
     */
    /**
     * 
     * Unmarshalls an Object from its value representation
     * 
     * @param str
     * @param reader
     *            The stream to read the text from.
     * @param context
     *            A context that allows nested objects to be processed by
     *            XStream.
     * @return The resulting object.
     */
    public Object fromString(String str, HierarchicalStreamReader reader,
            UnmarshallingContext context);
}
