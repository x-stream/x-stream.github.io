package npg.icecuber.xstream.converters.reflection;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import npg.icecuber.xstream.configuration.Configuration;
import npg.icecuber.xstream.converters.extended.ConverterToSingleValueConverterWrapper;
import npg.icecuber.xstream.core.TreeNullSafeMarshaller;
import npg.icecuber.xstream.mapper.AttributeClassAliasingMapper;
import npg.icecuber.xstream.mapper.FieldOfClassCustomConverterMapper;
import npg.icecuber.xstream.mapper.FieldOfClassDefaultValueMapper;

import org.apache.log4j.Logger;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.ConverterLookup;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.SingleValueConverter;
import com.thoughtworks.xstream.converters.reflection.ReflectionProvider;
import com.thoughtworks.xstream.converters.reflection.SerializationMethodInvoker;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.mapper.Mapper;

public class ReflectionVisitor implements ReflectionProvider.Visitor {
    /**
     * Logger for this class
     */
    private static final Logger logger = Logger
            .getLogger(ReflectionVisitor.class);

    private AttributeClassAliasingMapper attributeClassAliasingMapper;

    private FieldOfClassCustomConverterMapper fieldOfClassCustomConverterMapper;

    private FieldOfClassDefaultValueMapper fieldOfClassDefaultValueMapper;

    private HierarchicalStreamWriter writer;

    private Mapper mapper;

    private ConfigurableReflectionProvider reflectionProvider;

    private SerializationMethodInvoker serializationMethodInvoker;

    private MarshallingContext context;

    private transient Converter converter;

    private transient SingleValueConverter singleValueConverter;

    private ConverterLookup converterLookup;

    public ReflectionVisitor(ConfigurableReflectionProvider _reflectionProvider) {
        this.reflectionProvider = _reflectionProvider;
        this.mapper = reflectionProvider.getMapperProvider().getMapper();
        attributeClassAliasingMapper = reflectionProvider.getMapperProvider()
                .getAttributeClassAliasingMapper();
        fieldOfClassCustomConverterMapper = reflectionProvider
                .getMapperProvider().getFieldOfClassCustomConverterMapper();
        fieldOfClassDefaultValueMapper = reflectionProvider.getMapperProvider()
                .getFieldOfClassDefaultValueMapper();
        converterLookup = reflectionProvider.getMapperProvider()
                .getConverterLookup();
        serializationMethodInvoker = new SerializationMethodInvoker();
    }

    public void visit(String fieldName, Class fieldType, Class definedIn,
            Object value) {
        if (logger.isDebugEnabled()) {
            logger.debug("visit(String, Class, Class, Object) - start");
            logger.debug("name vale: " + fieldName + " fieldType vale: "
                    + fieldType + " definedIn vale: " + definedIn
                    + " value vale: " + value);
        }
        String nomeComeAttributo;
        if (!mapper.shouldSerializeMember(definedIn, fieldName))
            return;
        if ((value == null || "".equals(value))
                && fieldOfClassDefaultValueMapper.hasFieldOfClassDefaultValue(
                        fieldName, definedIn)) {
            // il fieldName � nullo ma ha un default value
            value = fieldOfClassDefaultValueMapper
                    .getDefaultValueForFieldOfClass(fieldName, definedIn);
        }
        if (attributeClassAliasingMapper.isFieldOfClassToParentTagAttribute(
                fieldName, definedIn)) {
            // devo farne un'attributo!!
            // di nome
            nomeComeAttributo = attributeClassAliasingMapper
                    .getAliasForFieldOfClassToParentTagAttribute(fieldName,
                            definedIn);
            singleValueConverter = this.getSingleValueConverterFor(fieldName,
                    fieldType, definedIn);
            if (singleValueConverter == null) {
                writer.addAttribute(nomeComeAttributo, "" + value);
            } else
                writer.addAttribute(nomeComeAttributo, singleValueConverter
                        .toString(value));

            if (logger.isDebugEnabled()) {
                logger.debug("visit(String, Class, Class, Object) - end");
            }
            return;
        }
        List interfaceImpemeted = Arrays.asList(fieldType.getInterfaces());
        if (interfaceImpemeted.contains(Collection.class)) {
            // � una qlc collection!!!
            Collection collectionCorrente = (Collection) value;
            if (Configuration.isAlwaysImplicitCommetcion()) {
                // devo sempre fare implicit collection
                this.processImplicitCollection(collectionCorrente, definedIn);

                if (logger.isDebugEnabled()) {
                    logger.debug("visit(String, Class, Class, Object) - end");
                }
                return;
            } else {
                // non sempre devo sempre fare implicit collection - controllo
                // quando
                Mapper.ImplicitCollectionMapping mapping = mapper
                        .getImplicitCollectionDefForFieldName(value.getClass(),
                                fieldName);
                if (mapping == null) {
                    // dovrebbe essere che non ho Implicit Collection
                    // Lascio convertire al convertitore di default
                    context.convertAnother(value);

                    if (logger.isDebugEnabled()) {
                        logger
                                .debug("visit(String, Class, Class, Object) - end");
                    }
                    return;
                }
                // dovrebbe essere che ho Implicit Collection
                if (mapping.getItemFieldName() != null) {
                    // ok di questa devo fare implicit collection
                    this.processImplicitCollection(collectionCorrente,
                            definedIn);
                    return;
                } else {
                    // Questa Collection NON � Implicita
                    context.convertAnother(value);
                    return;
                }
            }
        }
        this.writeField(fieldName, fieldName, fieldType, definedIn, value);
    }

    public HierarchicalStreamWriter getWriter() {
        return writer;
    }

    public void setWriter(HierarchicalStreamWriter writer) {
        this.writer = writer;
    }

    private void processImplicitCollection(Collection collectionCorrente,
            Class definedIn) {
        Class actualType;
        String fieldNameAndAlias;
        Iterator iteratoreCollectionCorrente;
        Object elementoCorrente;
        iteratoreCollectionCorrente = collectionCorrente.iterator();
        while (iteratoreCollectionCorrente.hasNext()) {
            elementoCorrente = iteratoreCollectionCorrente.next();
            actualType = serializationMethodInvoker.callWriteReplace(
                    elementoCorrente).getClass();
            fieldNameAndAlias = mapper.serializedClass(actualType);
            this.writeField(fieldNameAndAlias, fieldNameAndAlias, actualType,
                    definedIn, elementoCorrente);
        }
    }

    private void writeField(String fieldName, String aliasName,
            Class fieldType, Class definedIn, Object newObj) {
        if (logger.isDebugEnabled()) {
            logger
                    .debug("writeField(String, String, Class, Class, Object) - start");
            logger.debug("\nfieldName vale: " + fieldName
                    + "\naliasName vale: " + aliasName + "\nfieldType vale: "
                    + fieldType + "\ndefinedIn vale: " + definedIn
                    + "\nnewObj vale: " + newObj);
        }

        // attenzione alle cglib col mapper messo dovrebbe filtarle..
        // speriamo!!!
        writer.startNode(mapper.serializedMember(definedIn, aliasName));
        if (fieldType != null && newObj != null) {
            Class actualType = newObj.getClass();
            if (Configuration.isCGLibResolvesToClassNeeded()) {
                Class defaultType = mapper.defaultImplementationOf(fieldType);
                if (!actualType.equals(defaultType)) {
                    writer.addAttribute(mapper
                            .attributeForImplementationClass(), mapper
                            .serializedClass(actualType));
                }
            }

        }
        if (newObj != null) {
            if (attributeClassAliasingMapper.isFieldOfClassToOwnTagAttribute(
                    fieldName, definedIn)) {
                // deve fare l'attributo di un prorpio tag
                // il nome del tag � quello definito nei classici alias
                // il nome dell'attributo lo ricavo dal mapping
                singleValueConverter = this.getSingleValueConverterFor(
                        fieldName, fieldType, definedIn);
                if (singleValueConverter == null) {
                    writer.addAttribute(attributeClassAliasingMapper
                            .getAliasForFieldOfClassToOwnTagAttribute(
                                    fieldName, definedIn), "" + newObj);

                } else {
                    writer.addAttribute(attributeClassAliasingMapper
                            .getAliasForFieldOfClassToOwnTagAttribute(
                                    fieldName, definedIn), singleValueConverter
                            .toString(newObj));

                }

            } else {
                converter = this.getConverterFor(fieldName, fieldType,
                        definedIn);
                context.convertAnother(newObj, converter);
            }

        }
        writer.endNode();

        if (logger.isDebugEnabled()) {
            logger
                    .debug("writeField(String, String, Class, Class, Object) - end");
        }
    }

    public ConverterLookup getConverterLookup() {
        return converterLookup;
    }

    public void setConverterLookup(ConverterLookup converterLookup) {
        this.converterLookup = converterLookup;
    }

    public MarshallingContext getContext() {
        return context;
    }

    public void setContext(MarshallingContext _context) {
        this.context = _context;
    }

    private Converter getConverterFor(String fieldName, Class fieldType,
            Class definedIn) {
        Converter converter = null;
        if (fieldOfClassCustomConverterMapper.hasFieldOfClassCustomConverter(
                fieldName, definedIn)) {
            // il presente fieldName ha un CustomConverter
            converter = fieldOfClassCustomConverterMapper
                    .getCustomConverterForFieldOfClass(fieldName, definedIn);
        } else
            converter = converterLookup.lookupConverterForType(fieldType);
        return converter;

    }

    private SingleValueConverter getSingleValueConverterFor(String fieldName,
            Class fieldType, Class definedIn) {
        Converter converter = this.getConverterFor(fieldName, fieldType,
                definedIn);
        if (converter == null)
            return null;
        return new ConverterToSingleValueConverterWrapper(converter, context);

    }

}
