/**
 * 
 */
package npg.icecuber.xstream.converters.reflection;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import npg.icecuber.xstream.mapper.FieldOrderMapper;

import com.thoughtworks.xstream.converters.reflection.FieldDictionary;

/**
 * @author stefano.girotti
 * 
 */
public class OrderFieldDictionary extends FieldDictionary {
    private FieldOrderMapper fieldOrderMapper;

    private transient boolean daSerializzare;

    private transient boolean giaPresente;

    /**
     * @param fieldOrderMapper
     */
    public OrderFieldDictionary(FieldOrderMapper fieldOrderMapper) {
        // TODO Auto-generated constructor stub
        this.fieldOrderMapper = fieldOrderMapper;
    }

    @Override
    public Iterator serializableFieldsFor(Class cls) {
        Iterator itera = super.serializableFieldsFor(cls);
        if (fieldOrderMapper.getFieldOrderList(cls).size() < 1) {
            // non ho alcun ordine - ritorno l'iteratore cosi' com'e'
            return itera;
        }
        // filtro gi� qua tutti i field che sono da omettere
        Field field;
        HashMap mappaNonOrdinata = new HashMap();
        while (itera.hasNext()) {
            field = (Field) itera.next();

            mappaNonOrdinata.put(field.getName(), field);
        }
        itera = fieldOrderMapper.getFieldOrderList(cls).iterator();
        ArrayList listaOrdinata = new ArrayList();
        while (itera.hasNext()) {
            String fieldName = "" + itera.next();

            listaOrdinata.add(mappaNonOrdinata.get(fieldName));
        }
        // ho messo in testa i campi ordinati
        // ora devo aggiungere gli altri
        itera = mappaNonOrdinata.keySet().iterator();
        while (itera.hasNext()) {
            String fieldName = "" + itera.next();
            field = (Field) mappaNonOrdinata.get(fieldName);
            daSerializzare = fieldOrderMapper.shouldSerializeMember(cls, field
                    .getName());
            giaPresente = listaOrdinata.contains(field);
            if (fieldOrderMapper.shouldSerializeMember(cls, field.getName())
                    && !listaOrdinata.contains(field)) {
                // se non ho gia' inserito il field corrente
                // lo inserisco ora
                listaOrdinata.add(field);
            }

        }
        return listaOrdinata.iterator();
    }

}
