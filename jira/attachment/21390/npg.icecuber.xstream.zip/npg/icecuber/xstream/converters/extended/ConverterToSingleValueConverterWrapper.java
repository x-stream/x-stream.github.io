package npg.icecuber.xstream.converters.extended;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.SingleValueConverter;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.converters.basic.AbstractSingleValueConverter;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.io.xml.XppDriver;
import java.io.StringWriter;

/**
 * @author  stefano.girotti
 */
public class ConverterToSingleValueConverterWrapper implements
        SingleValueConverter {

    private Converter converterWrapped;

    private MarshallingContext context;

    private XppDriver xppDriver;

    private StringWriter scrittore;

    /**
     * @param _converterWrapped
     * @param _context
     */
    public ConverterToSingleValueConverterWrapper(Converter _converterWrapped,
            MarshallingContext _context) {
        this.converterWrapped = _converterWrapped;
        this.context = _context;
        xppDriver = new XppDriver();
        scrittore = new StringWriter();
    }

    public String toString(Object obj) {
        // devo generare un HierarchicalStreamWriter da cui prendo
        // l'informazione convertita
        HierarchicalStreamWriter HSW = xppDriver.createWriter(scrittore);
        converterWrapped.marshal(obj, HSW, context);
        HSW.flush();
        scrittore.flush();
        return scrittore.toString().trim();
    }

    public boolean canConvert(Class type) {
        return converterWrapped.canConvert(type);
    }

    public Object fromString(String str) {
        // TODO Auto-generated method stub
        return null;
    }

}
