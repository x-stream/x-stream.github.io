/**
 * 
 */
package npg.icecuber.xstream.converters.basic;

import npg.icecuber.xstream.configuration.Configuration;

import com.thoughtworks.xstream.converters.basic.StringConverter;

/**
 * @author stefano.girotti
 * 
 */
public class ConfigurableStringConverter extends StringConverter {

    /**
     * 
     */
    public ConfigurableStringConverter() {
        super();
        // TODO Auto-generated constructor stub
    }

    public String toString(Object obj) {
        if (obj == null)
            return "";
        String retValue = ""+super.toString(obj);
        if (Configuration.isTrimAlwaysNeeded()) {
            return retValue.trim();
        }
        return retValue;
    }
}
