package npg.icecuber.xstream.converters.extended;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.SingleValueConverter;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

/**
 * @author  stefano.girotti
 */
public class SingleValueConverterToConverterWrapper implements Converter {

    private SingleValueConverter converterWrapped;

    // private MarshallingContext context;
    //
    // private XppDriver xppDriver;
    //
    // private StringWriter scrittore;

    /**
     * @param _converterWrapped
     */
    public SingleValueConverterToConverterWrapper(
            SingleValueConverter _converterWrapped) {
        // TODO Auto-generated constructor stub
        this.converterWrapped = _converterWrapped;
    }

    public boolean canConvert(Class type) {
        return converterWrapped.canConvert(type);
    }

    public void marshal(Object source, HierarchicalStreamWriter writer,
            MarshallingContext context) {
        writer.setValue(converterWrapped.toString(source));
    }

    public Object unmarshal(HierarchicalStreamReader reader,
            UnmarshallingContext context) {
        return null;
    }

    public Object fromString(String str) {
        // TODO Auto-generated method stub
        return null;
    }

}
