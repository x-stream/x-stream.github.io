/**
 * 
 */
package npg.icecuber.xstream.converters.reflection;

import com.thoughtworks.xstream.converters.reflection.Sun14ReflectionProvider;
import npg.icecuber.xstream.mapper.MapperProvider;

/**
 * @author  stefano.girotti
 */
public class ConfigurableReflectionProvider extends Sun14ReflectionProvider {
    private OrderFieldDictionary orderFieldDictionary;

    private MapperProvider mapperProvider;

    // private FieldOrderMapper fieldOrderMapper;

    /**
     * @param mapperProvider
     */
    public ConfigurableReflectionProvider(MapperProvider mapperProvider) {
        super();
        this.mapperProvider = mapperProvider;
        super.fieldDictionary = new OrderFieldDictionary(mapperProvider
                .getFieldOrderMapper());
    }

    /**
	 * @return  Returns the orderFieldDictionary.
	 * @uml.property  name="orderFieldDictionary"
	 */
    public OrderFieldDictionary getOrderFieldDictionary() {
        return orderFieldDictionary;
    }

    /**
	 * @param orderFieldDictionary  The orderFieldDictionary to set.
	 * @uml.property  name="orderFieldDictionary"
	 */
    public void setOrderFieldDictionary(
            OrderFieldDictionary orderFieldDictionary) {
        this.orderFieldDictionary = orderFieldDictionary;
    }

    /**
	 * @return  Returns the mapperProvider.
	 * @uml.property  name="mapperProvider"
	 */
    public MapperProvider getMapperProvider() {
        return mapperProvider;
    }

    /**
	 * @param mapperProvider  The mapperProvider to set.
	 * @uml.property  name="mapperProvider"
	 */
    public void setMapperProvider(MapperProvider mapperWrapperProvider) {
        this.mapperProvider = mapperWrapperProvider;
    }

}
