/**
 * 
 */
package npg.icecuber.xstream.converters.extended;

import java.sql.Time;

import com.thoughtworks.xstream.converters.basic.DateConverter;

/**
 * @author stefano.girotti
 * 
 */
public class SQLTimeStampFormatConverter extends DateConverter {

    /**
     * @param pattern
     */
    public SQLTimeStampFormatConverter(String defaultFormat,
            String[] acceptableFormats) {
        super(defaultFormat, acceptableFormats);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.thoughtworks.xstream.converters.Converter#canConvert(java.lang.Class)
     */
    public boolean canConvert(Class classeDaConvertire) {
        if (classeDaConvertire == null)
            return false;
        return classeDaConvertire.equals(Time.class);
    }
}
