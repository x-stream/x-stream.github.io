/**
 *
 */
package npg.icecuber.xstream;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.converters.reflection.ReflectionProvider;
import com.thoughtworks.xstream.io.HierarchicalStreamDriver;
import com.thoughtworks.xstream.io.xml.XppDriver;
import com.thoughtworks.xstream.mapper.Mapper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import npg.icecuber.xstream.mapper.MapperProvider;

/**
 * @author  stefano.girotti
 */
public class ConfigurableXStream extends XStream {
	// private AttributeClassAliasingMapper attributeClassAliasingMapper;

	// private Mapper mapper;

	private MapperProvider mapperProvider;

	/**
	 * @return  Returns the mapperProvider.
	 * @uml.property  name="mapperProvider"
	 */
	public MapperProvider getMapperProvider() {
		return mapperProvider;
	}

	/**
	 * @param mapperProvider  The mapperProvider to set.
	 * @uml.property  name="mapperProvider"
	 */
	public void setMapperProvider(MapperProvider mapperProvider) {
		this.mapperProvider = mapperProvider;
	}

	/**
	 *
	 */
	public ConfigurableXStream() {
		this(null, null, new XppDriver());
	}

	/**
	 * @param hierarchicalStreamDriver
	 */
	public ConfigurableXStream(HierarchicalStreamDriver hierarchicalStreamDriver) {
		this(null, null, hierarchicalStreamDriver);
		// super(hierarchicalStreamDriver);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param reflectionProvider
	 */
	public ConfigurableXStream(ReflectionProvider reflectionProvider) {
		this(reflectionProvider, null, null);
		// super(reflectionProvider);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param reflectionProvider
	 * @param hierarchicalStreamDriver
	 */
	public ConfigurableXStream(ReflectionProvider reflectionProvider,
			HierarchicalStreamDriver hierarchicalStreamDriver) {
		this(reflectionProvider, null, hierarchicalStreamDriver);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param reflectionProvider
	 * @param mapper
	 * @param driver
	 */
	// public ConfigurableXStream(ReflectionProvider reflectionProvider,
	// Mapper mapper, HierarchicalStreamDriver driver) {
	// this(reflectionProvider, mapper, driver);
	// // TODO Auto-generated constructor stub
	// }
	/**
	 * @param reflectionProvider
	 * @param mapper
	 * @param driver
	 * @param classAttributeIdentifier
	 */
	public ConfigurableXStream(ReflectionProvider reflectionProvider,
			Mapper mapper, HierarchicalStreamDriver driver) {
		super(reflectionProvider, mapper, driver);
		mapperProvider = new MapperProvider(super.getMapper(), super
				.getConverterLookup());
	}

	public void omitFieldList(Class type, List fieldListToOmit) {
		Iterator itera = fieldListToOmit.iterator();
		while (itera.hasNext()) {
			this.omitField(type, "" + itera.next());
		}
	}

	public void omitFieldList(Class type, String[] fieldOrderArray) {
		this.omitFieldList(type, Arrays.asList(fieldOrderArray));
	}

	public void omitFieldList(Class type,
			String fieldOrderListCommaSeparetedFiledName) {
		this.omitFieldList(type, fieldOrderListCommaSeparetedFiledName, ",");
	}

	public void omitFieldList(Class type,
			String fieldOrderListCustomSeparetedFiledName, String delim) {
		StringTokenizer stok = new StringTokenizer(
				fieldOrderListCustomSeparetedFiledName, delim, false);
		ArrayList<String> fieldOrderList = new ArrayList<String>();
		while (stok.hasMoreTokens()) {
			fieldOrderList.add(stok.nextToken());
		}
		// this.setFieldOrderList(type, fieldOrderList);
		this.omitFieldList(type, fieldOrderList);
	}
}
