/**
 * 
 */
package npg.icecuber.xstream.mapper;

import com.thoughtworks.xstream.converters.ConverterLookup;
import com.thoughtworks.xstream.mapper.Mapper;
import com.thoughtworks.xstream.mapper.MapperWrapper;
import java.util.HashMap;
import java.util.Map;

/**
 * @author  stefano.girotti
 */
public class MapperProvider {
    private HashMap mapperWrapperMap;

    private Mapper mapper;

    // private FieldOfClassDefaultValueMapper fieldOfClassDefaultValueMapper =
    // null;

    private ConverterLookup converterLookup;

    //
    // private FieldOrderMapper fieldOrderMapper = null;
    //
    // private FieldOfClassCustomConverterMapper
    // fieldOfClassCustomConverterMapper = null;

    /**
     * 
     */
    public MapperProvider(Mapper _mapper, ConverterLookup _converterLookup) {
        super();
        mapperWrapperMap = new HashMap();
        this.mapper = _mapper;
        converterLookup = _converterLookup;
        this.setAttributeClassAliasingMapper(new AttributeClassAliasingMapper(
                _mapper));
        this
                .setFieldOfClassCustomConverterMapper(new FieldOfClassCustomConverterMapper(
                        _mapper));
        this
                .setFieldOfClassDefaultValueMapper(new FieldOfClassDefaultValueMapper(
                        _mapper));
        this.setFieldOrderMapper(new FieldOrderMapper(_mapper));
    }

    public MapperWrapper get(String mapperWrapperName) {
        return (MapperWrapper) mapperWrapperMap.get(mapperWrapperName);
    }

    public MapperWrapper put(String mapperWrapperName,
            MapperWrapper mapperWrapper) {
        return (MapperWrapper) mapperWrapperMap.put(mapperWrapperName,
                mapperWrapper);
    }

    public void putAll(Map _mapperWrapperMap) {
        mapperWrapperMap.putAll(_mapperWrapperMap);
    }

    public AttributeClassAliasingMapper getAttributeClassAliasingMapper() {
        return (AttributeClassAliasingMapper) this
                .get("attributeClassAliasingMapper");
    }

    public void setAttributeClassAliasingMapper(
            AttributeClassAliasingMapper attributeClassAliasingMapper) {
        this.put("attributeClassAliasingMapper", attributeClassAliasingMapper);
    }

    public FieldOfClassCustomConverterMapper getFieldOfClassCustomConverterMapper() {
        return (FieldOfClassCustomConverterMapper) this
                .get("fieldOfClassCustomConverterMapper");
    }

    public void setFieldOfClassCustomConverterMapper(
            FieldOfClassCustomConverterMapper fieldOfClassCustomConverterMapper) {
        this.put("fieldOfClassCustomConverterMapper",
                fieldOfClassCustomConverterMapper);
    }

    public FieldOrderMapper getFieldOrderMapper() {
        return (FieldOrderMapper) this.get("fieldOrderMapper");
    }

    public void setFieldOrderMapper(FieldOrderMapper fieldOrderMapper) {
        this.put("fieldOrderMapper", fieldOrderMapper);
    }

    /**
     * @return Returns the fieldOfClassDefaultValueMapper.
     */
    public FieldOfClassDefaultValueMapper getFieldOfClassDefaultValueMapper() {
        return (FieldOfClassDefaultValueMapper) this
                .get("fieldOfClassDefaultValueMapper");
    }

    /**
     * @param fieldOfClassDefaultValueMapper
     *            The fieldOfClassDefaultValueMapper to set.
     */
    public void setFieldOfClassDefaultValueMapper(
            FieldOfClassDefaultValueMapper fieldOfClassDefaultValueMapper) {
        this.put("fieldOfClassDefaultValueMapper",
                fieldOfClassDefaultValueMapper);
    }

    /**
	 * @return  Returns the mapper.
	 * @uml.property  name="mapper"
	 */
    public Mapper getMapper() {
        return mapper;
    }

    /**
	 * @param mapper  The mapper to set.
	 * @uml.property  name="mapper"
	 */
    public void setMapper(Mapper _mapper) {
        this.mapper = _mapper;
    }

    /**
	 * @return  Returns the converterLookup.
	 * @uml.property  name="converterLookup"
	 */
    public ConverterLookup getConverterLookup() {
        return converterLookup;
    }

    /**
	 * @param converterLookup  The converterLookup to set.
	 * @uml.property  name="converterLookup"
	 */
    public void setConverterLookup(ConverterLookup converterLookup) {
        this.converterLookup = converterLookup;
    }

}
