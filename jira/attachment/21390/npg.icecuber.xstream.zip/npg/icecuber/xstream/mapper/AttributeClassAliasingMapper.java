package npg.icecuber.xstream.mapper;

import java.lang.reflect.Field;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.thoughtworks.xstream.mapper.Mapper;
import com.thoughtworks.xstream.mapper.MapperWrapper;

public class AttributeClassAliasingMapper extends MapperWrapper {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = Logger
			.getLogger(AttributeClassAliasingMapper.class);

	// mappa
	private HashMap<String, HashMap<String, String>> fieldToParentTagAttributeMap = new HashMap<String, HashMap<String, String>>();

	private HashMap<String, HashMap<String, String>> fieldToOwnTagWithAttributeMap = new HashMap<String, HashMap<String, String>>();

	public AttributeClassAliasingMapper(Mapper wrapped) {
		super(wrapped);
	}

	//
	// public AttributeClassAliasingMapper(Mapper wrapped,
	// ConverterLookup converterLookup) {
	// super(wrapped, converterLookup);
	//
	// }

	public boolean isFieldOfClassToParentTagAttribute(String fieldName,
			Class definedInClass) {
		if (logger.isDebugEnabled()) {
			logger.debug("isFieldOfClassToAttribute(String, Class) - start");
		}

		// se non ho mappings per questa classe
		if (!fieldToParentTagAttributeMap.containsKey(definedInClass.getName()))
			return false;

		HashMap classMap = (HashMap) fieldToParentTagAttributeMap
				.get(definedInClass.getName());
		boolean returnboolean = classMap.containsKey(fieldName);
		if (logger.isDebugEnabled()) {
			logger.debug("isFieldOfClassToAttribute(String, Class) - end");
		}
		return returnboolean;
	}

	public void addAliasForFieldOfClassToParentTagAttribute(
			final String fieldName, final String fieldNameAttributeAliasName,
			final Class definedInClass) {
		HashMap<String, String> classMap;
		// ottengo l'effectiveField - il campo con la corretta indicazione di
		// dove viene dichiarato
		Field effectiveField = MapperToolZ.getEffectiveFieldByFieldNameOfClass(
				fieldName, definedInClass);
		if (effectiveField == null) {
			logger.debug("Non ho trovato il Campo " + fieldName
					+ " nella classe " + definedInClass.getName());
			return;
		}
		Class effectiveDeclaringClass = effectiveField.getDeclaringClass();
		// controllo se ho gi� mapping per questa classe
		// se ho gi� un mapping lo ricavo
		classMap = fieldToParentTagAttributeMap.get(effectiveDeclaringClass
				.getName());
		if (classMap == null) {
			// se non ne ho, creo un HashMap apposta
			classMap = new HashMap<String, String>();
		}
		// aggiungo il mapping della classe
		classMap.put(fieldName, fieldNameAttributeAliasName);
		// aggiungo il mapping della classe ai mapping
		fieldToParentTagAttributeMap.put(effectiveDeclaringClass.getName(),
				classMap);
	}

	public String getAliasForFieldOfClassToParentTagAttribute(
			final String fieldName, final Class definedInClass) {

		HashMap classMap;
		// controllo se ho gi� mapping per questa classe
		if (fieldToParentTagAttributeMap.containsKey(definedInClass.getName())) {
			// se ho gi� un mapping lo ricavo
			classMap = (HashMap) fieldToParentTagAttributeMap
					.get(definedInClass.getName());
			// e ritorno il corrispondente mapping
			return "" + classMap.get(fieldName);
		} else {
			// se non ne ho, ritorno lo stesso fieldName
			return fieldName;
		}
	}

	public boolean isFieldOfClassToOwnTagAttribute(String fieldName,
			Class definedInClass) {
		if (logger.isDebugEnabled()) {
			logger.debug("isFieldOfClassToAttribute(String, Class) - start");
		}

		// se non ho mappings per questa classe
		if (!fieldToOwnTagWithAttributeMap
				.containsKey(definedInClass.getName()))
			return false;

		HashMap classMap = (HashMap) fieldToOwnTagWithAttributeMap
				.get(definedInClass.getName());
		boolean returnboolean = classMap.containsKey(fieldName);
		if (logger.isDebugEnabled()) {
			logger.debug("isFieldOfClassToAttribute(String, Class) - end");
		}
		return returnboolean;
	}

	public void addAliasForFieldOfClassToOwnTagAttribute(
			final String fieldName, final String fieldNameAttributeAliasName,
			final Class definedInClass) {
		// ottengo l'effectiveField - il campo con la corretta indicazione di
		// dove viene dichiarato
		Field effectiveField = MapperToolZ.getEffectiveFieldByFieldNameOfClass(
				fieldName, definedInClass);
		if (effectiveField == null) {
			logger.debug("Non ho trovato il Campo " + fieldName
					+ " nella classe " + definedInClass.getName());
			return;
		}
		Class effectiveDeclaringClass = effectiveField.getDeclaringClass();
		HashMap<String, String> classMap;
		// controllo se ho gi� mapping per questa classe
		if (fieldToOwnTagWithAttributeMap.containsKey(effectiveDeclaringClass
				.getName())) {
			// se ho gi� un mapping lo ricavo
			classMap = fieldToOwnTagWithAttributeMap
					.get(effectiveDeclaringClass.getName());
		} else {
			// se non ne ho, creo un HashMap apposta
			classMap = new HashMap<String, String>();
		}
		// aggiungo il mapping della classe
		classMap.put(fieldName, fieldNameAttributeAliasName);
		// aggiungo il mapping della classe ai mapping
		fieldToOwnTagWithAttributeMap.put(effectiveDeclaringClass.getName(),
				classMap);
	}

	public String getAliasForFieldOfClassToOwnTagAttribute(
			final String fieldName, final Class definedInClass) {
		HashMap classMap;
		// controllo se ho gi� mapping per questa classe
		if (fieldToOwnTagWithAttributeMap.containsKey(definedInClass.getName())) {
			// se ho gi� un mapping lo ricavo
			classMap = (HashMap) fieldToOwnTagWithAttributeMap
					.get(definedInClass.getName());
			// e ritorno il corrispondente mapping
			return "" + classMap.get(fieldName);
		} else {
			// se non ne ho, ritorno lo stesso fieldName
			return fieldName;
		}
	}
}

// Field fieldCorrente = null;
// while ((fieldCorrente == null)
// && (!Object.class.equals(effectiveDeclaringClass))) {
// try {
// fieldCorrente = effectiveDeclaringClass
// .getDeclaredField(fieldName);
//
// } catch (SecurityException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// } catch (NoSuchFieldException e) {
// effectiveDeclaringClass = effectiveDeclaringClass
// .getSuperclass();
// e.printStackTrace();
// }
// }
