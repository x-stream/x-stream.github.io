package npg.icecuber.xstream.mapper;

import java.lang.reflect.Field;

public class MapperToolZ {
	public static Field getEffectiveFieldByFieldNameOfClass(final String fieldName,
			final Class apparentlyDefinedInClass) {
		Class effectiveDeclaringClass = apparentlyDefinedInClass;
		Field fieldCorrente = null;
		while ((fieldCorrente == null)
				&& (!Object.class.equals(effectiveDeclaringClass))) {
			try {
				fieldCorrente = effectiveDeclaringClass
						.getDeclaredField(fieldName);
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
			} catch (NoSuchFieldException e) {
				effectiveDeclaringClass = effectiveDeclaringClass
						.getSuperclass();
				// e.printStackTrace();
			}
		}
		return fieldCorrente;
	}
}
