/**
 * 
 */
package npg.icecuber.xstream.mapper;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.mapper.Mapper;

/**
 * @author IceCubeR
 * 
 */
public interface ExtendableMapper extends Mapper {

    public boolean isConditionForFieldOfTypeDefinedInClass(int condition,
            String fieldName, Object value, Class fieldType,
            Class definedInClass);

    public Converter getConverterForFieldOfTypeDefinedInClass(
            int converterType, String fieldName, Object value, Class fieldType,
            Class definedInClass);

    public void addConverterForFieldOfTypeDefinedInClass(int converterType,
            String fieldName, Object value, Class fieldType,
            Class definedInClass, Converter converter);

    public String getAliasForFieldOfTypeDefinedInClass(
            int AliasType, String fieldName, Object value, Class fieldType,
            Class definedInClass);

    public void addAliasForFieldOfTypeDefinedInClass(int converterType,
            String fieldName, Object value, Class fieldType,
            Class definedInClass, String alias);
    
    // public SingleValueConverter
    // getSingleValueConverterForFieldOfTypeDefinedInClass(
    // int converterType, String fieldName, Object value, Class fieldType,
    // Class definedInClass);
    //
    // public void addSingleValueConverterForFieldOfTypeDefinedInClass(
    // int converterType, String fieldName, Object value, Class fieldType,
    // Class definedInClass);
}
