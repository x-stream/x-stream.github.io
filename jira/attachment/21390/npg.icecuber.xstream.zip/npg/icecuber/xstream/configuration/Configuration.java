package npg.icecuber.xstream.configuration;

import java.io.Serializable;

/**
 * @author  stefano.girotti
 */
public class Configuration implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private static String utilDateFormat = "";

	private static String sqlDateFormat = "";

	private static String sqlTimeFormat = "";

	private static String sqlTimeStampFormat = "";

	private static String[] acceptableDateTimeFormats = {
			"yyyy-MM-dd HH:mm:ss.S a", "yyyy-MM-dd HH:mm:ssz",
			"yyyy-MM-dd HH:mm:ss z", // JDK 1.3 needs both versions
			"yyyy-MM-dd HH:mm:ssa" };

	private static boolean alwaysImplicitCollection = true;

	private static boolean alwaysImplicitMap = true;

	private static boolean trimAlwaysNeeded = true;

	private static boolean filteringCGLibAlwaysNeeded = true;

	private static boolean CGLibResolvesToClassNeeded = false;

	/**
	 * @return  Returns the filteringCGLibAlwaysNeeded.
	 * @uml.property  name="filteringCGLibAlwaysNeeded"
	 */
	public static boolean isFilteringCGLibAlwaysNeeded() {
		return filteringCGLibAlwaysNeeded;
	}

	/**
	 * @param filteringCGLibAlwaysNeeded  The filteringCGLibAlwaysNeeded to set.
	 * @uml.property  name="filteringCGLibAlwaysNeeded"
	 */
	public static void setFilteringCGLibAlwaysNeeded(boolean alwaysFilterCGLib) {
		Configuration.filteringCGLibAlwaysNeeded = alwaysFilterCGLib;
	}

	/**
	 * @return  Returns the alwaysImplicitCollection.
	 * @uml.property  name="alwaysImplicitCollection"
	 */
	public static boolean isAlwaysImplicitCollection() {
		return alwaysImplicitCollection;
	}

	/**
	 * @param alwaysImplicitCollection  The alwaysImplicitCollection to set.
	 * @uml.property  name="alwaysImplicitCollection"
	 */
	public static void setAlwaysImplicitCollection(
			boolean alwaysImplicitCommetcion) {
		Configuration.alwaysImplicitCollection = alwaysImplicitCommetcion;
	}

	/**
	 * @return  Returns the sqlDateFormat.
	 * @uml.property  name="sqlDateFormat"
	 */
	public static String getSqlDateFormat() {
		return sqlDateFormat;
	}

	/**
	 * @param sqlDateFormat  The sqlDateFormat to set.
	 * @uml.property  name="sqlDateFormat"
	 */
	public static void setSqlDateFormat(String sqlDateFormat) {
		Configuration.sqlDateFormat = sqlDateFormat;
	}

	/**
	 * @return  Returns the sqlTimeFormat.
	 * @uml.property  name="sqlTimeFormat"
	 */
	public static String getSqlTimeFormat() {
		return sqlTimeFormat;
	}

	/**
	 * @param sqlTimeFormat  The sqlTimeFormat to set.
	 * @uml.property  name="sqlTimeFormat"
	 */
	public static void setSqlTimeFormat(String sqlTimeFormat) {
		Configuration.sqlTimeFormat = sqlTimeFormat;
	}

	/**
	 * @return  Returns the utilDateFormat.
	 * @uml.property  name="utilDateFormat"
	 */
	public static String getUtilDateFormat() {
		return utilDateFormat;
	}

	/**
	 * @param utilDateFormat  The utilDateFormat to set.
	 * @uml.property  name="utilDateFormat"
	 */
	public static void setUtilDateFormat(String utilDateFormat) {
		Configuration.utilDateFormat = utilDateFormat;
	}

	/**
	 * @return  Returns the cGLibResolvesToClassNeeded.
	 * @uml.property  name="cGLibResolvesToClassNeeded"
	 */
	public static boolean isCGLibResolvesToClassNeeded() {
		return CGLibResolvesToClassNeeded;
	}

	/**
	 * @param cGLibResolvesToClassNeeded  The cGLibResolvesToClassNeeded to set.
	 * @uml.property  name="cGLibResolvesToClassNeeded"
	 */
	public static void setCGLibResolvesToClassNeeded(
			boolean suppressCGLibResolvesTo) {
		Configuration.CGLibResolvesToClassNeeded = suppressCGLibResolvesTo;
	}

	/**
	 * @return  Returns the trimAlwaysNeeded.
	 * @uml.property  name="trimAlwaysNeeded"
	 */
	public static boolean isTrimAlwaysNeeded() {
		return trimAlwaysNeeded;
	}

	/**
	 * @param trimAlwaysNeeded  The trimAlwaysNeeded to set.
	 * @uml.property  name="trimAlwaysNeeded"
	 */
	public static void setTrimAlwaysNeeded(boolean alwaysTrim) {
		Configuration.trimAlwaysNeeded = alwaysTrim;
	}

	/**
	 * @return  Returns the sqlTimeStampFormat.
	 * @uml.property  name="sqlTimeStampFormat"
	 */
	public static String getSqlTimeStampFormat() {
		return sqlTimeStampFormat;
	}

	/**
	 * @param sqlTimeStampFormat  The sqlTimeStampFormat to set.
	 * @uml.property  name="sqlTimeStampFormat"
	 */
	public static void setSqlTimeStampFormat(String sqlTimeStampFormat) {
		Configuration.sqlTimeStampFormat = sqlTimeStampFormat;
	}

	/**
	 * @return  Returns the acceptableDateTimeFormats.
	 * @uml.property  name="acceptableDateTimeFormats"
	 */
	public static String[] getAcceptableDateTimeFormats() {
		return acceptableDateTimeFormats;
	}

	/**
	 * @param acceptableDateTimeFormats  The acceptableDateTimeFormats to set.
	 * @uml.property  name="acceptableDateTimeFormats"
	 */
	public static void setAcceptableDateTimeFormats(
			String[] acceptableDateTimeFormats) {
		Configuration.acceptableDateTimeFormats = acceptableDateTimeFormats;
	}

	/**
	 * @return  Returns the alwaysImplicitMap.
	 * @uml.property  name="alwaysImplicit"
	 */
	public static boolean isAlwaysImplicitMap() {
		return alwaysImplicitMap;
	}

	/**
	 * @param alwaysImplicitMap  The alwaysImplicitMap to set.
	 * @uml.property  name="alwaysImplicit"
	 */
	public static void setAlwaysImplicitMap(boolean alwaysImplicitMap) {
		Configuration.alwaysImplicitMap = alwaysImplicitMap;
	}

}
