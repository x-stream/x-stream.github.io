package npg.icecuber.xstream.core;

import org.apache.log4j.Logger;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.ConverterLookup;
import com.thoughtworks.xstream.core.TreeMarshaller;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.mapper.Mapper;

public class TreeNullSafeMarshaller extends TreeMarshaller {
    /**
     * Logger for this class
     */
    private static final Logger logger = Logger
            .getLogger(TreeNullSafeMarshaller.class);


    /**
     * @param writer
     * @param _converterLookup
     * @param mapper
     */
    public TreeNullSafeMarshaller(HierarchicalStreamWriter writer,
            ConverterLookup _converterLookup, Mapper mapper) {
        super(writer, _converterLookup, mapper);
    }

    public void convertAnother(Object item) {
        if (item == null)
            item = "";
        super.convertAnother(item);
    }

    protected void convert(Object item, Converter converter) {
        if (logger.isDebugEnabled()) {
            logger.debug("convert(Object, Converter) - start");
        }
        if (item == null)
            item = "";
        if (logger.isDebugEnabled()) {
            logger.debug("converto l'oggetto " + item + "\ncol Converter "
                    + converter);
        }
        super.convert(item, converter);

        if (logger.isDebugEnabled()) {
            logger.debug("convert(Object, Converter) - end");
        }
    }

}
