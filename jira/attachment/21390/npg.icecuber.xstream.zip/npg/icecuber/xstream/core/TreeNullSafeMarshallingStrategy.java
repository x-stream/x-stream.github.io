package npg.icecuber.xstream.core;

import com.thoughtworks.xstream.converters.ConverterLookup;
import com.thoughtworks.xstream.converters.DataHolder;
import com.thoughtworks.xstream.core.TreeMarshallingStrategy;
import com.thoughtworks.xstream.core.TreeUnmarshaller;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.mapper.Mapper;

public class TreeNullSafeMarshallingStrategy extends TreeMarshallingStrategy {

	public void marshal(HierarchicalStreamWriter writer, Object obj,
			ConverterLookup converterLookup, Mapper mapper,
			DataHolder dataHolder) {
		new TreeNullSafeMarshaller(writer, converterLookup, mapper).start(obj,
				dataHolder);
	}

	public Object unmarshal(Object root, HierarchicalStreamReader reader,
			DataHolder dataHolder, ConverterLookup converterLookup,
			Mapper mapper) {
		return new TreeUnmarshaller(root, reader, converterLookup, mapper)
				.start(dataHolder);
	}

}
